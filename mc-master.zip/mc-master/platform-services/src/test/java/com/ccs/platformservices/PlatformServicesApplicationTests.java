package com.ccs.platformservices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PlatformServicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
