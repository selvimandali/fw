package com.ccs.platformservices;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PlatformServicesApplication {

	public static void main(String[] args) {
		SpringApplication.run(PlatformServicesApplication.class, args);
	}

}
