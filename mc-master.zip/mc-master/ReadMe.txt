SETP1: CREATING A "creditcardsystem" IN YOUR LOCAL MYSQL DATABASE

SETP2: OPEN THE credit-card-apply-service.yml, credit-card-approve-service.yml and provide your database credentials,email credentials
yourpath\737230-MC\platform-services\config-server\src\main\resources\configurationRepository

STEP3: AFTER IMPORTING THE PROJECTS INTO YOUR IDE AND START THE PROJECTS IN THE ORDER OF REGISTRY SERVER,CONFIGSERVER,CREDIT-CARD-APPLY-SERVICE,CREDITCARD-APPROVE-SERVICE,API-GATEWAY-SERVICE

SETP4: OPEN http://localhost:7004/credit-card-apply-service/swagger-ui.html#/, http://ctsjavafs46.iiht.tech:7004/credit-card-approve-service/swagger-ui.html#/
TO SEE THE SWAGGER UI FOR BOTH SERVICES
